// ***************************************************
// * CS460: Programming Assignment 3: Test Program 6 *
// ***************************************************
procedure main (void)
{
  char buffer[-5]; // syntax error: array size must be declared as a positive integer
}

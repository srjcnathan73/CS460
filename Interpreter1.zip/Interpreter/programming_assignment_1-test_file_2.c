// ***************************************************
// * CS460: Programming Assignment 1: Test Program 2 *
// ***************************************************
procedure main (void)
{
  int /* hidden; int */ counter; 

  counter = /*2*/ 100;
/* hidden = */ /*5;*/
  printf ("counter = %d\n", counter);
}

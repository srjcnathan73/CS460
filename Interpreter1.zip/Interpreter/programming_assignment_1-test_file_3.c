// ***************************************************
// * CS460: Programming Assignment 1: Test Program 3 *
// ***************************************************
//procedure main (/*avoid*/void)
procedure main (/*avoid*/void)
{
  int /* hidden; char */ counter; 

  counter = /*2*/ 101;
/* hidden = */ /*5;*/
  printf ("counter = %d\n", counter);
  printf ("/* Will this string be displayed? */\n");
/*
}
*/
}


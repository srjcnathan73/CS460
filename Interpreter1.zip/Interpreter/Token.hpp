//
// Created by Nwseb on 2/9/2025.
//

#ifndef INTERPRETER_TOKEN_HPP
#define INTERPRETER_TOKEN_HPP

#include <string>

class Token {
public:
    Token() {}
    bool &eof() { return _eof; }
    bool isForwardSlash()   { return _symbol == '/'; }
    bool isStar()   { return _symbol == '*'; }
    bool isIgnoredText()   { return _symbol == ' '; }

    char &symbol() { return _symbol; }
    std::string toString(); // return string representation of token

private:
    char _symbol = '\0';
    bool _eof = false;
};


#endif //INTERPRETER_TOKEN_HPP

#include <iostream>
#include <fstream>
#include <cstring>
#include "Constants.hpp"
#include "CommentRemover.hpp"


void verifyReadableInputFile(char* fileName);

int main(int argc, char *argv[]) {
    if (argc < 2 || argc > 2) {
        std::cerr << errorMessages[E_WRONG_NUMBER_ARGS] << std::endl;
        exit(E_WRONG_NUMBER_ARGS);
    }
    // Verify that the command-line argument is a legitimate, readable file
    // Exit with error if not.
    verifyReadableInputFile(argv[argc - 1]);
    CommentRemover commentRemover(argv[argc - 1]);
    commentRemover.removeComments();
    std::vector<char>* fileBuffer = commentRemover.getFileBuffer();
    std::ofstream newFile;
    char *addStart = (char*)"Output/";
    char *copy = argv[argc - 1];
    copy[strlen(copy)-3] = '\0';
    char *addEnding = (char*)"-test_file_1-comments_replaced_with_whitespace.c";
    const unsigned int newWordSize = 120;
    char newFileName[newWordSize];
    std::strcpy(newFileName, addStart);
    std::strcat(newFileName, copy);
    std::strcat(newFileName, addEnding);

    std::cout << newFileName << std::endl;
    newFile.open (newFileName);
    for(size_t i=0;i<fileBuffer->size();i++){
        newFile << fileBuffer->at(i);
    }
    newFile.close();
    return 0;
}

void verifyReadableInputFile(char* fileName) {
    std::fstream inputStream;
    inputStream.open(fileName, std::ios::in);

    if (!inputStream.is_open()) {
        std::cerr << errorMessages[E_BAD_INPUT_FILE] << fileName << std::endl;
        exit(E_BAD_INPUT_FILE);
    }
    inputStream.close(); // close file! Parser will reopen it later.
}
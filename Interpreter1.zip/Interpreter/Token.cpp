//
// Created by Nwseb on 2/9/2025.
//
#include <cassert>
#include <string>
#include "Token.hpp"

std::string Token::toString() {
    if (isForwardSlash() || isStar() || isIgnoredText()) {
        return std::string(1, symbol());
    }
    else if (eof()) {
        return "EOF";
    }

    // this should never happen!
    assert(true); // if we reach this point, our program has a bug -- exit!
    return "Unknown token!";
}
//
// Created by Nwseb on 2/9/2025.
//

#ifndef INTERPRETER_TOKEN_HPP
#define INTERPRETER_TOKEN_HPP

#include <string>

class Token {
public:
    Token(std::string tokenValue, std::string tokenType);
    Token *next();
    void next(Token *token);
    std::string tokenValue();
    std::string tokenType();

private:
    Token *_next;
    std::string _token;
    std::string _type;
};

#endif //INTERPRETER_TOKEN_HPP

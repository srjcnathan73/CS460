/***************************************************
 * CS460: Programming Assignment 4: Test Program 4 *
 ***************************************************/

char my_string[1024];


procedure main (void)
{
  result = TRUE;
  my_string[0] = '\x0';
  number = 3;
}


int number;


function bool random_long_parameter_list (int ensity, char ter, int rospective, int egrity, char latan, char coal, int elligent, bool lean, char treuse, char ming, int uitive)
{
  i = 1;
  j = 1000;
  k = 25;
  return TRUE;
}

bool result;

procedure do_nothing (void)
{
}

int i, j, k;

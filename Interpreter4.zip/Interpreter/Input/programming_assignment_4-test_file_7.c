/***************************************************
 * CS460: Programming Assignment 4: Test Program 7 *
 ***************************************************/


procedure main (void)
{
  char string[256];
  int string_size;

  string_size = 256;
  my_procedure (string, string_size);
}


procedure my_procedure (char string[4096], int string_size)
{
  int string_size;

  string_size = 256;
}
